# NovLearn Exercise Engine

`novlearn-exercise-engine` est une bibliothèque TypeScript qui définit, génère,
instancie et corrige des exercices mathématiques. Elle fournit des règles communes
à NovLearn élève, NovLearn Admin et aux duels pour éviter des calculs et des
corrections divergents entre applications.

Le package privé **0.1.0** est ESM, utilise le **schéma 5** et repose sur
**CortexJS 0.151.0**, son unique bibliothèque mathématique principale. Le cœur
portable ne dépend d’aucun framework ni de MathLive. Un adaptateur Node optionnel
isole les calculs côté serveur ; le rendu, les droits, le stockage et les points
appartiennent aux applications.

## Disponible aujourd’hui

- Génération reproductible d’entiers, décimaux exacts, choix, tuples et variables
  calculées rationnelles, avec exclusions, dépendances et contraintes bornées.
- Exercices à plusieurs questions, sections et QCM ; données typées pour graphes,
  tableaux, suites, arbres, vecteurs et figures, sans renderer graphique.
- Instance privée contenant les attendus ; projection publique par sélection de
  champs ; correction par question depuis l’instance officielle du serveur.
- Correction numérique, algébrique, ensembles et intervalles dans des profils
  précis ; formes pédagogiques et tolérances explicites. Une preuve insuffisante
  donne `indeterminate`, une panne donne `error`.
- Huit adaptations historiques locales, banc MathLive/FastAPI et consommation
  réelle du package documentés. Aucune migration de production effectuée.

La [requalification du 13–14 octobre](docs/certification/windows-requalification.md)
fait passer la suite source à **1534 tests**, sans skip. Le smoke natif du vrai
tarball installé échoue toutefois sous Smart App Control Windows ; la
certification de cet artefact reste bloquée. Les contrôles Linux bornés (12),
les huit parcours historiques et Python/FastAPI (13) passent séparément.
Le [rapport initial](docs/certification/report.md) reste une preuve historique.
Le moteur ne fournit pas de CAS universel,
solveur général de limites/dérivées, correction libre multivariée ou complexe,
éditeur Admin ni interface de production. L’hôte Linux exige un cgroup v2 borné ;
le launcher Windows distribué reste bloqué dans la dernière requalification. Les
[capacités et limites](docs/features.md) précisent ce qui est garanti et testé.

## Démarrer dans le dépôt

Prérequis : **Node 24.19.x et npm 11.17.x**.

```powershell
npm.cmd ci
npm.cmd run check
npm.cmd pack --dry-run
```

`check` construit le package puis exécute types, lint, format et Vitest. Le
package est privé : le tarball local sert aux consommateurs, sans publication
automatique. Voir [installation et maintenance](docs/development.md).

Après installation du tarball dans un projet ESM, la lecture d’une saisie utilise
l’API exportée :

```ts
import { parseMathInput } from 'novlearn-exercise-engine';

const parsed = parseMathInput('1{,}25');
if (!parsed.ok) console.log(parsed.diagnostics);
// Le parsing conserve la source ; il ne prouve ni la valeur ni le domaine.
```

Le [guide d’utilisation](docs/usage.md) donne un exemple complet et vérifié :
définition avec deux questions → génération → instance privée → projection →
soumission → correction, puis rejeu et erreurs.

## Lire la documentation

Commencer par [l’index](docs/README.md), puis [l’architecture](docs/architecture.md).
Les [capacités](docs/features.md) décrivent les profils opérationnels ; la
[matrice CDC](docs/feature-coverage.md) relie les exigences à leurs preuves.
[Progression](docs/progress.md) et [roadmap](docs/roadmap.md) permettent la reprise.
Les [décisions](docs/decisions.md) et leurs ADR conservent les justifications.

Le [cahier des charges officiel](docs/CDC_référence.md) décrit la cible validée.
Les [archives](docs/archive/README.md) conservent les bilans historiques.
